
#include <iostream>
using namespace std;

class Department {
public:
    void printDepartmentName() { cout << "Computer Science" << std::endl; }
};

// Composite class
class University {
private:
    Department department; // Composition
public:
    void printUniversityInfo() {
        std::cout << "University Name: XYZ University" << std::endl;
        department.printDepartmentName(); // Delegating to component
    }
};

int main() {
    University xyzUniversity;
    xyzUniversity.printUniversityInfo();
    return 0;
}
