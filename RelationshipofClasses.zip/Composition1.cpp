
#include <iostream>
using namespace std;


class Engine {
public:
    void start() {
        cout << "Engine started" << endl;
    }
};

class Wheels {
public:
    void rotate() {
        cout << "Wheels rotating" << endl;
    }
};



class Car {
private:
    Engine engine;
    Wheels wheel;

public:
    void startCar() {
        engine.start();
        wheel.rotate();
        cout << "Car started moving" << endl;
    }
};

int main() {
    Car myCar;
    myCar.startCar();

    return 0;
}


