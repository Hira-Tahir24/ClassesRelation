
#include <iostream>
using namespace std;


// Contained class
class Book {
public:
    std::string title;
    Book(std::string t) : title(t) {}
};

// Aggregating class
class Library {
private:
    Book* books[10]; // Aggregation
    int count;
public:
    Library() : count(0) {}
    void addBook(Book* b) {
        if (count < 10) {
            books[count] = b;
            count++;
        }
    }
    void printBooks() {
        for (int i = 0; i < count; i++) {
            std::cout << books[i]->title << std::endl;
        }
    }
};

int main() {
    Library lib;
    Book b1("Book 1");
    Book b2("Book 2");
    lib.addBook(&b1);
    lib.addBook(&b2);
    lib.printBooks();
    return 0;
}
