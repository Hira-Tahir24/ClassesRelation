#include <iostream>
using namespace std;
class Course {
public:
    void displayCourse() {
        cout << "Displaying course details." << endl;
    }
};

class Student {
public:
    void attendCourse(Course* course) {
        course->displayCourse();
    }
};

int main() {
    Course course1;
    Student student1;
    student1.attendCourse(&course1);
    return 0;
}