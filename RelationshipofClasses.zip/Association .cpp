
#include <iostream>
#include <string>
using namespace std;

class Teacher {
public:
    string name;
    string subject;

    Teacher(string n, string sub) {
        name = n;
        subject = sub;
    }

    void display() {
        cout << "Teacher Name: " << name << endl;
        cout << "Teaches: " << subject << endl;
    }
    ~Teacher()
    { cout <<"Teacher class destroyed"<<endl;}
};

class Student {
public:
    string name;
    int studentId;
    Teacher* teacher;

    Student(string n, int id, Teacher* t) {
        name = n;
        studentId = id;
        teacher = t;
    }

    void display() {
        cout << "Student Name: " << name << endl;
        cout << "Student ID: " << studentId << endl;
        cout << "Teacher: ";
        teacher->display();
    }
    ~Student()
    { cout <<"Student class destroyed"<<endl;}
};

int main() {
    Teacher t("Mr. Smith", "Mathematics");
    Student s("Alice", 123, &t);

    s.display();

    return 0;
}
