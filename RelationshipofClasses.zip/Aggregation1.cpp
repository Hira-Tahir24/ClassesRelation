
#include <iostream>
using namespace std;

// Aggregated class
class Student {
public:
    std::string name;
    Student(std::string n) : name(n) {}
};

// Aggregating class
class University {
private:
    Student* students[10]; // Aggregation
    int count;
public:
    University() : count(0) {}
    void addStudent(Student* s) {
        if (count < 10) {
            students[count] = s;
            count++;
        }
    }
    void printStudents() {
        for (int i = 0; i < count; i++) {
            std::cout << students[i]->name << std::endl;
        }
    }
};

int main() {
    University uni;
    Student s1("John");
    Student s2("Alice");
    uni.addStudent(&s1);
    uni.addStudent(&s2);
    uni.printStudents();
    return 0;
}
